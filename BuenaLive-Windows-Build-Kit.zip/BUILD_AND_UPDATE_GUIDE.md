# BuenaLive - Build and Update Guide

Complete guide for building, distributing, and updating the BuenaLive application.

## Table of Contents

1. [Overview](#overview)
2. [Prerequisites](#prerequisites)
3. [Building the Application](#building-the-application)
4. [Publishing Updates](#publishing-updates)
5. [User Update Experience](#user-update-experience)
6. [Troubleshooting](#troubleshooting)

---

## Overview

BuenaLive uses a modern auto-update system powered by:
- **PyInstaller**: Packages Python app into standalone executables
- **tufup**: Secure auto-update framework based on The Update Framework (TUF)
- **GitHub Releases**: Hosts update files (or use your own server)

### Update Flow

```
Developer                          User
    │                               │
    ├─ 1. Update version.py         │
    ├─ 2. Build app                 │
    ├─ 3. Publish update            │
    ├─ 4. Upload to server     ────>│
    │                               ├─ 5. Click "Buscar actualizaciones"
    │                               ├─ 6. Download & install
    │                               └─ 7. Restart app
```

---

## Prerequisites

### For Development

1. **Python 3.8+** with virtual environment:
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # Mac/Linux
   # or
   venv\Scripts\activate     # Windows
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Platform-specific tools**:

   **macOS:**
   - Xcode Command Line Tools: `xcode-select --install`
   - (Optional) create-dmg: `brew install create-dmg`

   **Windows:**
   - Visual Studio C++ Build Tools
   - (Optional) NSIS: Download from https://nsis.sourceforge.io/

### For Users

- **macOS**: macOS 10.13+ (High Sierra or newer)
- **Windows**: Windows 7+ (64-bit)
- **Chrome browser** installed (for Selenium automation)
- Internet connection (for updates)

---

## Building the Application

### Step 1: Update Version Number

Edit `version.py` and increment the version:

```python
# version.py
__version__ = "1.0.1"  # Change this before building
```

**Version format**: Follow [Semantic Versioning](https://semver.org/)
- `MAJOR.MINOR.PATCH` (e.g., 1.2.3)
- `MAJOR`: Breaking changes
- `MINOR`: New features (backward compatible)
- `PATCH`: Bug fixes

### Step 2: Build for Your Platform

#### macOS Build

```bash
# Activate virtual environment
source venv/bin/activate

# Clean build (recommended for releases)
python build_scripts/build_mac.py --clean

# Create .dmg installer (optional but recommended)
python build_scripts/build_mac.py --dmg --clean
```

**Output:**
- `dist/BuenaLive.app` - macOS application bundle
- `dist/BuenaLive-{version}-mac.dmg` - Installer (if --dmg used)

**Testing:**
```bash
open dist/BuenaLive.app
```

#### Windows Build

```bash
# Activate virtual environment
venv\Scripts\activate

# Clean build
python build_scripts/build_windows.py --clean

# Create installer (optional but recommended)
python build_scripts/build_windows.py --installer --clean
```

**Output:**
- `dist/BuenaLive.exe` - Windows executable
- `dist/BuenaLive-Setup-{version}.exe` - Installer (if --installer used)

**Testing:**
```bash
dist\BuenaLive.exe
```

### Step 3: Test the Build

Before publishing, verify:

1. **Application launches** without errors
2. **All features work**:
   - Credential management
   - Google Sheets connection
   - Event selection
   - Ticket automation
3. **Update button appears** in UI (but may fail to connect - this is OK for initial build)

---

## Publishing Updates

### First Time Setup

Initialize the tufup repository (only needed once):

```bash
python build_scripts/publish_update.py --init-repo
```

This creates:
- `tufup_repo/metadata/` - TUF metadata files (signed)
- `tufup_repo/targets/` - Application archives and patches

### Publishing a New Version

After building your application:

```bash
# Activate virtual environment
source venv/bin/activate  # Mac
# or
venv\Scripts\activate     # Windows

# Publish the built application
python build_scripts/publish_update.py
```

**What this does:**
1. Finds built app in `dist/`
2. Creates compressed archive: `BuenaLive-{version}.tar.gz`
3. Generates patch from previous version (if exists)
4. Updates and signs TUF metadata
5. Stores everything in `tufup_repo/`

**Options:**
```bash
# Skip patch generation (force full download)
python build_scripts/publish_update.py --skip-patch

# Use custom repository directory
python build_scripts/publish_update.py --repo-dir /path/to/repo
```

### Hosting Updates

You need to make `tufup_repo/` accessible via HTTPS. Two options:

#### Option 1: GitHub Releases (Recommended)

1. **Create a new release** on GitHub:
   ```bash
   git tag v1.0.1
   git push origin v1.0.1
   ```

2. **Go to GitHub repository** → Releases → Create new release

3. **Upload files**:
   - Upload entire `tufup_repo/metadata/` directory
   - Upload entire `tufup_repo/targets/` directory
   - Upload installer (`.dmg` or `.exe`) as release asset

4. **Update `updater.py`** with your repository URL:
   ```python
   # updater.py
   UPDATE_REPO_URL = os.getenv(
       "BUENA_LIVE_UPDATE_URL",
       "https://github.com/YOUR_USERNAME/buena-live-updates/raw/main"
   )
   ```

#### Option 2: Custom Server

1. **Upload `tufup_repo/` to your web server**:
   ```bash
   rsync -av tufup_repo/ user@server:/var/www/updates/
   ```

2. **Ensure HTTPS and correct permissions**:
   ```bash
   chmod -R 755 /var/www/updates/
   ```

3. **Update `updater.py`**:
   ```python
   UPDATE_REPO_URL = "https://your-server.com/updates"
   ```

### Environment Variable (Recommended for Testing)

Instead of hardcoding URLs, use environment variable:

```bash
export BUENA_LIVE_UPDATE_URL="https://your-test-server.com/updates"
```

---

## User Update Experience

### How Users Update

1. **Launch BuenaLive application**
2. **See version** in title bar: "Emisión de Tickets - Buena Live v1.0.0"
3. **Click "Buscar actualizaciones"** button in Actualizaciones section
4. **If update available:**
   - Dialog shows: "Nueva versión X.X.X disponible"
   - Click "Yes" to download and install
   - Progress bar shows download progress
5. **After installation:**
   - Dialog asks to restart
   - Click "Yes" to restart automatically
6. **Application relaunches** with new version

### Automatic Checking (Optional)

To enable automatic update checks on startup, add to `AutomationGUI.__init__`:

```python
def __init__(self):
    # ... existing code ...
    self.setup_ui()

    # Check for updates on startup (after UI is ready)
    self.root.after(2000, self.check_for_updates_silently)

def check_for_updates_silently(self):
    """Check for updates without blocking UI"""
    def check():
        try:
            available, version = updater.check_for_updates()
            if available:
                self.root.after(0, self._show_update_dialog, version)
        except:
            pass  # Fail silently

    threading.Thread(target=check, daemon=True).start()
```

---

## Troubleshooting

### Build Issues

#### "Module not found" errors
```bash
# Reinstall dependencies
pip install --force-reinstall -r requirements.txt
```

#### "PyInstaller: command not found"
```bash
# Ensure virtual environment is activated
source venv/bin/activate  # Mac/Linux
venv\Scripts\activate     # Windows

# Reinstall PyInstaller
pip install pyinstaller
```

#### Mac: ".app is damaged" or "cannot be opened"
```bash
# Remove quarantine attribute
xattr -cr dist/BuenaLive.app

# For distribution, you need to sign the app:
codesign --force --deep --sign - dist/BuenaLive.app
```

#### Windows: "Missing DLL" errors
- Install Visual C++ Redistributable: https://aka.ms/vs/17/release/vc_redist.x64.exe

### Update Issues

#### Updates not appearing

1. **Check repository URL**:
   ```python
   # In updater.py, verify URL is correct
   print(UPDATE_REPO_URL)
   ```

2. **Verify server is accessible**:
   ```bash
   curl https://your-server.com/updates/metadata/1.root.json
   ```

3. **Check logs** in application

#### "Cannot verify signatures" error

- This happens if metadata is corrupted or repository wasn't initialized
- Reinitialize repository: `python build_scripts/publish_update.py --init-repo`
- Republish all versions

#### Updates download but don't apply

- Check permissions on installation directory
- Try running as administrator (Windows) or with sudo (Mac)
- Check available disk space

### Testing Updates Locally

Create a local test server:

```bash
# In tufup_repo directory
python3 -m http.server 8000

# In another terminal, set environment variable
export BUENA_LIVE_UPDATE_URL="http://localhost:8000"

# Run your app
python main.py
```

---

## Version History Tracking

Keep a `CHANGELOG.md` to track versions:

```markdown
# Changelog

## [1.0.1] - 2025-01-15
### Fixed
- Bug in ticket emission for innominados
- Credential save dialog timing

## [1.0.0] - 2025-01-01
### Added
- Initial release
- Auto-update functionality
```

---

## Security Notes

### Code Signing (Recommended for Distribution)

**macOS:**
```bash
# Sign the app (requires Apple Developer account)
codesign --deep --force --verify --verbose \
  --sign "Developer ID Application: Your Name" \
  --options runtime \
  dist/BuenaLive.app

# Notarize for macOS 10.15+
xcrun notarytool submit dist/BuenaLive-1.0.0-mac.dmg \
  --apple-id your@email.com \
  --password app-specific-password \
  --team-id TEAM_ID
```

**Windows:**
```bash
# Sign the exe (requires code signing certificate)
signtool sign /f certificate.pfx /p password /t http://timestamp.digicert.com dist/BuenaLive.exe
```

### TUF Security

tufup uses The Update Framework which provides:
- **Signed metadata**: Prevents unauthorized updates
- **Rollback protection**: Prevents downgrade attacks
- **Mix-and-match attacks**: Prevents serving mismatched versions
- **Arbitrary software attacks**: Cryptographic verification

Keep your TUF keys secure! They're stored in `tufup_repo/metadata/`.

---

## Quick Reference

### Common Commands

```bash
# Build Mac app
python build_scripts/build_mac.py --dmg --clean

# Build Windows app
python build_scripts/build_windows.py --installer --clean

# Initialize update repository (first time only)
python build_scripts/publish_update.py --init-repo

# Publish new version
python build_scripts/publish_update.py

# Test locally
python main.py
```

### File Structure

```
buena-live/
├── main.py                    # Main application
├── version.py                 # VERSION constant
├── updater.py                 # Update logic
├── credential_manager.py      # Credential handling
├── credentials.json           # Google Sheets credentials
├── buena-live.spec            # PyInstaller config
├── requirements.txt           # Python dependencies
├── build_scripts/
│   ├── build_mac.py          # Mac build script
│   ├── build_windows.py      # Windows build script
│   └── publish_update.py     # Update publisher
├── dist/                      # Built applications (generated)
├── build/                     # Build artifacts (generated)
└── tufup_repo/               # Update repository (generated)
    ├── metadata/             # TUF metadata
    └── targets/              # App archives and patches
```

---

## Support

For issues or questions:
1. Check this guide first
2. Review logs in the application
3. Create an issue on GitHub repository
4. Contact the development team

---

**Last updated:** 2025-01-09
**Version:** 1.0.0
