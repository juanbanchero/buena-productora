# BuenaLive Ticket Automation

Automated ticket purchasing system for BuenaLive events with secure credential management, auto-updates, and Google Sheets integration.

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![Python](https://img.shields.io/badge/python-3.8+-green)
![Platform](https://img.shields.io/badge/platform-macOS%20%7C%20Windows-lightgrey)

## Features

- 🎫 **Automated ticket purchasing** - Process multiple tickets from Google Sheets
- 🔒 **Secure credential storage** - Encrypted credentials with automatic loading
- 📊 **Google Sheets integration** - Track purchases and manage ticket data
- 🔄 **Auto-updates** - Built-in update system for easy version management
- 🖥️ **Cross-platform** - Works on macOS and Windows
- 🎯 **Dual modes** - Support for both nominados (with personal data) and innominados (without)

## Quick Start

### For Users

1. **Download the installer**:
   - macOS: Download `BuenaLive-{version}-mac.dmg`
   - Windows: Download `BuenaLive-Setup-{version}.exe`

2. **Install and run**:
   - macOS: Open the .dmg and drag BuenaLive to Applications
   - Windows: Run the setup .exe and follow the installer

3. **Configure**:
   - Enter your BuenaLive credentials
   - Paste your Google Sheets URL
   - Click "Conectar Sistemas"

4. **Start automation**:
   - Select your event
   - Choose "Iniciar Emisión Nominados" or "Iniciar Emisión Innominados"

### For Developers

See [BUILD_AND_UPDATE_GUIDE.md](BUILD_AND_UPDATE_GUIDE.md) for complete build and deployment instructions.

#### Quick Setup

```bash
# Clone the repository
git clone <repository-url>
cd buena-live

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # Mac/Linux
# or
venv\Scripts\activate     # Windows

# Install dependencies
pip install -r requirements.txt

# Run the application
python main.py
```

## System Requirements

### Users
- **macOS**: 10.13 (High Sierra) or newer
- **Windows**: Windows 7 or newer (64-bit)
- **Chrome browser** installed
- **Internet connection** for Google Sheets and updates

### Developers
- **Python**: 3.8 or newer
- **Chrome browser** and ChromeDriver
- **Platform tools**:
  - macOS: Xcode Command Line Tools
  - Windows: Visual C++ Build Tools

## Project Structure

```
buena-live/
├── main.py                    # Main application with GUI
├── version.py                 # Application version
├── updater.py                 # Auto-update module
├── credential_manager.py      # Secure credential handling
├── credentials.json           # Google Sheets API credentials
├── buena-live.spec            # PyInstaller configuration
├── requirements.txt           # Python dependencies
├── build_scripts/             # Build and publish scripts
│   ├── build_mac.py          # macOS build script
│   ├── build_windows.py      # Windows build script
│   └── publish_update.py     # Update publisher
├── BUILD_AND_UPDATE_GUIDE.md # Complete build documentation
└── CLAUDE.md                  # Project architecture and guidelines
```

## How It Works

### Ticket Automation
1. Connects to BuenaLive POS system using Selenium WebDriver
2. Reads ticket data from Google Sheets
3. Automates ticket purchase process:
   - Selects event and sector
   - Fills in attendee information (nominados) or skips (innominados)
   - Processes payment
   - Captures ticket numbers
4. Updates Google Sheets with results

### Security
- **Credential encryption**: Uses Fernet (AES) with machine-specific keys
- **Automatic key generation**: Derives keys from username, machine, and project
- **Transparent operation**: Automatically encrypts on save, decrypts on load
- **No plaintext storage**: Credentials never stored unencrypted

### Auto-Updates
- **Secure updates**: Based on The Update Framework (TUF)
- **Incremental patches**: Downloads only changes between versions
- **One-click updates**: Users click "Buscar actualizaciones" to check and install
- **Automatic restart**: App restarts after successful update

## Building and Distribution

See [BUILD_AND_UPDATE_GUIDE.md](BUILD_AND_UPDATE_GUIDE.md) for complete instructions.

### Quick Build

**macOS:**
```bash
python build_scripts/build_mac.py --dmg --clean
```

**Windows:**
```bash
python build_scripts/build_windows.py --installer --clean
```

### Publishing Updates

```bash
# First time setup
python build_scripts/publish_update.py --init-repo

# Publish new version
python build_scripts/publish_update.py
```

## Usage Examples

### Nominados (With Personal Data)

Google Sheets format:
```
| Nombre | Apellido | Email            | Documento | Sector |
|--------|----------|------------------|-----------|--------|
| Juan   | Pérez    | juan@email.com   | 12345678  | VIP    |
```

### Innominados (Without Personal Data)

Google Sheets format:
```
| Cantidad | Sector | Función |
|----------|--------|---------|
| 5        | VIP    | 20:00   |
```

## Configuration

### Google Sheets API

1. Create a Google Cloud project
2. Enable Google Sheets API
3. Create service account credentials
4. Download credentials as `credentials.json`
5. Share your Google Sheet with the service account email

### Update Server

Edit `updater.py` to configure update URL:

```python
UPDATE_REPO_URL = os.getenv(
    "BUENA_LIVE_UPDATE_URL",
    "https://your-server.com/updates"
)
```

Or set environment variable:
```bash
export BUENA_LIVE_UPDATE_URL="https://your-server.com/updates"
```

## Troubleshooting

### "Chrome driver not found"
- Install Chrome browser
- Ensure ChromeDriver is in PATH or same directory as application

### "Cannot connect to Google Sheets"
- Verify `credentials.json` is present
- Check service account has access to the sheet
- Ensure sheet URL is correct

### "Update check fails"
- Verify update server URL in `updater.py`
- Check internet connection
- Ensure update repository is accessible via HTTPS

### macOS: "App is damaged"
```bash
xattr -cr /Applications/BuenaLive.app
```

For more troubleshooting, see [BUILD_AND_UPDATE_GUIDE.md](BUILD_AND_UPDATE_GUIDE.md#troubleshooting).

## Architecture

### Key Components

**TicketAutomation** (`main.py:21-1229`)
- Core automation engine
- Selenium WebDriver control
- Event and ticket management
- Google Sheets integration

**AutomationGUI** (`main.py:1232-1692`)
- Tkinter-based user interface
- Credential management
- Update checking and installation
- Real-time logging

**CredentialManager** (`credential_manager.py:10-115`)
- Secure credential storage
- Automatic encryption/decryption
- Machine-specific key derivation

**BuenaLiveUpdater** (`updater.py:40-240`)
- Update checking via tufup
- Secure download and verification
- Application restart

### Dependencies

Core libraries:
- `selenium` - Web automation
- `gspread` - Google Sheets API
- `cryptography` - Credential encryption
- `tufup` - Auto-update framework
- `tkinter` - GUI (standard library)

See `requirements.txt` for complete list.

## Development

### Running Tests

```bash
# Install test dependencies
pip install pytest pytest-cov

# Run tests
pytest

# With coverage
pytest --cov=. --cov-report=html
```

### Code Style

- Follow PEP 8 guidelines
- Use type hints where appropriate
- Document all public functions and classes
- Keep functions focused and short

### Contributing

1. Create a feature branch
2. Make your changes
3. Test thoroughly
4. Submit a pull request

## Security Notes

### Important
- **Never commit** `credentials.json` (Google Sheets API credentials)
- **Never commit** `*.enc` files (encrypted user credentials)
- Keep TUF signing keys secure (in `tufup_repo/metadata/`)

### Code Signing

For distribution, sign your application:

**macOS:**
```bash
codesign --deep --force --sign "Developer ID" dist/BuenaLive.app
```

**Windows:**
```bash
signtool sign /f cert.pfx /p password dist/BuenaLive.exe
```

## License

[Add your license here]

## Support

For issues, questions, or feature requests:
- Create an issue on GitHub
- Check [BUILD_AND_UPDATE_GUIDE.md](BUILD_AND_UPDATE_GUIDE.md) for documentation
- Contact the development team

## Changelog

See version history in [BUILD_AND_UPDATE_GUIDE.md](BUILD_AND_UPDATE_GUIDE.md#version-history-tracking).

### Current Version: 1.0.0
- Initial release with auto-update functionality
- Support for nominados and innominados ticket types
- Secure credential management
- Cross-platform builds (macOS and Windows)

---

**Built with** ❤️ **for BuenaLive**
