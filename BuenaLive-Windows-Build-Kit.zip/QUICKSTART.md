# Quick Start - BuenaLive Auto-Installer

Guía rápida para empezar con el sistema de instalador auto-actualizable.

## 🚀 Primera vez - Configuración

### 1. Activar entorno virtual
```bash
source venv/bin/activate
```

### 2. Verificar instalación
```bash
# Ver versión actual
python -c "from version import __version__; print(__version__)"

# Verificar tufup instalado
pip show tufup

# Verificar PyInstaller instalado
pip show pyinstaller
```

## 📦 Construir la aplicación

### Construir para Mac
```bash
# Build simple (solo .app)
python build_scripts/build_mac.py --clean

# Build con instalador .dmg (RECOMENDADO)
python build_scripts/build_mac.py --dmg --clean
```

**Salida**: `dist/BuenaLive.app` y `dist/BuenaLive-1.0.0-mac.dmg`

### Construir para Windows
```bash
# Build simple (solo .exe)
python build_scripts/build_windows.py --clean

# Build con instalador (RECOMENDADO)
python build_scripts/build_windows.py --installer --clean
```

**Salida**: `dist/BuenaLive.exe` y `dist/BuenaLive-Setup-1.0.0.exe`

## 🧪 Probar la aplicación

### Mac
```bash
# Abrir la aplicación
open dist/BuenaLive.app
```

### Windows
```bash
# Ejecutar
dist\BuenaLive.exe
```

## 🔄 Configurar sistema de actualizaciones

### Primera vez - Inicializar repositorio
```bash
python build_scripts/publish_update.py --init-repo
```

Esto crea la carpeta `tufup_repo/` con:
- `metadata/` - Archivos firmados de TUF
- `targets/` - Archivos de actualización

### Publicar versión actual
```bash
python build_scripts/publish_update.py
```

## 🌐 Subir actualizaciones a servidor

### Opción 1: GitHub Releases

1. **Crear release en GitHub**:
   ```bash
   git tag v1.0.0
   git push origin v1.0.0
   ```

2. **Ir a GitHub** → Releases → Create new release

3. **Subir archivos**:
   - `tufup_repo/metadata/` (toda la carpeta)
   - `tufup_repo/targets/` (toda la carpeta)
   - `dist/BuenaLive-1.0.0-mac.dmg` (como asset)
   - `dist/BuenaLive-Setup-1.0.0.exe` (como asset)

4. **Actualizar URL en `updater.py`**:
   ```python
   UPDATE_REPO_URL = "https://github.com/TU_USUARIO/buena-live/releases/download/v1.0.0"
   ```

### Opción 2: Servidor propio

```bash
# Subir con rsync
rsync -av tufup_repo/ usuario@servidor:/var/www/buena-live-updates/

# O con scp
scp -r tufup_repo/* usuario@servidor:/var/www/buena-live-updates/
```

Actualizar `updater.py`:
```python
UPDATE_REPO_URL = "https://tu-servidor.com/buena-live-updates"
```

## 🔄 Flujo completo para nueva versión

```bash
# 1. Actualizar versión
# Editar version.py: __version__ = "1.0.1"

# 2. Construir nueva versión
python build_scripts/build_mac.py --dmg --clean

# 3. Publicar actualización
python build_scripts/publish_update.py

# 4. Subir a servidor (GitHub o propio)
# Ver instrucciones arriba

# 5. Distribuir instalador a usuarios
```

## 🧪 Probar actualizaciones localmente

### 1. Crear servidor local
```bash
cd tufup_repo
python3 -m http.server 8000
```

### 2. En otra terminal, configurar URL local
```bash
export BUENA_LIVE_UPDATE_URL="http://localhost:8000"
```

### 3. Ejecutar aplicación
```bash
python main.py
```

### 4. Probar actualización
- Click en "Buscar actualizaciones"
- Debería encontrar la versión en el servidor local

## ✅ Checklist antes de distribuir

- [ ] Versión actualizada en `version.py`
- [ ] Aplicación construida sin errores
- [ ] Aplicación probada y funciona correctamente
- [ ] Update check funciona (OK si falla porque no hay servidor todavía)
- [ ] Repositorio de updates inicializado
- [ ] Versión publicada en repositorio
- [ ] Archivos subidos a servidor/GitHub
- [ ] URL de actualización configurada correctamente
- [ ] Instalador probado en sistema limpio

## 🐛 Troubleshooting rápido

### "Module not found"
```bash
pip install -r requirements.txt
```

### "pyinstaller: command not found"
```bash
# Asegurarse que venv está activado
source venv/bin/activate
pip install pyinstaller
```

### Mac: ".app is damaged"
```bash
xattr -cr dist/BuenaLive.app
```

### "No update available" cuando debería haber
1. Verificar URL en `updater.py`
2. Verificar servidor accesible: `curl $UPDATE_REPO_URL/metadata/1.root.json`
3. Verificar versión publicada es mayor a la instalada

## 📚 Documentación completa

Ver [BUILD_AND_UPDATE_GUIDE.md](BUILD_AND_UPDATE_GUIDE.md) para guía completa con:
- Explicación detallada de cada paso
- Troubleshooting extensivo
- Configuración de firma de código
- Mejores prácticas de seguridad

## 🎯 Comandos más usados

```bash
# Desarrollo
python main.py                                          # Ejecutar en desarrollo

# Build
python build_scripts/build_mac.py --dmg --clean        # Build Mac
python build_scripts/build_windows.py --installer      # Build Windows

# Updates
python build_scripts/publish_update.py --init-repo     # Primera vez
python build_scripts/publish_update.py                 # Publicar versión

# Testing
open dist/BuenaLive.app                                # Test Mac
dist/BuenaLive.exe                                     # Test Windows
```

## 🆘 ¿Necesitás ayuda?

1. Revisar este quickstart
2. Ver [BUILD_AND_UPDATE_GUIDE.md](BUILD_AND_UPDATE_GUIDE.md)
3. Crear issue en GitHub
4. Contactar al equipo de desarrollo
