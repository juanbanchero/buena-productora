# Cómo Generar el .exe para Windows

## ❗ IMPORTANTE

**PyInstaller NO puede crear .exe desde Mac**. Es una limitación técnica fundamental.

Para generar el .exe tenés 2 opciones:

---

## ✅ OPCIÓN 1: GitHub Actions (RECOMENDADO - Automático)

### Ventajas:
- ✅ **Automático** - GitHub lo hace por vos
- ✅ **Gratis** - No necesitás Windows
- ✅ **Siempre funciona** - Mismo resultado cada vez
- ✅ **Builds Mac + Windows juntos**

### Pasos (5 minutos):

**1. Subir código a GitHub:**

```bash
cd /Users/juanbanchero/Proyectos/buena-live

# Si no iniciaste git todavía
git init
git add .
git commit -m "Add BuenaLive with auto-update and logo"

# Crear repositorio en GitHub.com primero, luego:
git remote add origin https://github.com/TU_USUARIO/buena-live.git
git push -u origin main
```

**2. Crear tag (esto dispara el build):**

```bash
git tag v1.0.0
git push origin v1.0.0
```

**3. Esperar (~10 minutos):**

Ve a: `https://github.com/TU_USUARIO/buena-live/actions`

Verás:
```
🟡 Build and Release (v1.0.0) - Running...
   ├─ 🍎 Build macOS - Running...
   └─ 🪟 Build Windows - Running...
```

Después de ~10 minutos:
```
✅ Build and Release (v1.0.0) - Completed
   ├─ ✅ Build macOS - Success
   └─ ✅ Build Windows - Success
```

**4. Descargar el .exe:**

Ve a: `https://github.com/TU_USUARIO/buena-live/releases/tag/v1.0.0`

Verás:
```
📦 Release v1.0.0

   Assets:
   ├─ BuenaLive-1.0.0-mac.dmg ⬇️
   └─ BuenaLive.exe ⬇️  ← ¡Aquí está!
```

**¡LISTO!** Descargá el .exe y probalo en Windows.

---

## ✅ OPCIÓN 2: Buildear en Windows manualmente

Si tenés acceso a una PC Windows (tuya, de un amigo, o VM):

**1. Copiar estos archivos a la PC Windows:**

Todos los archivos del proyecto EXCEPTO:
- `venv/` (se crea de nuevo en Windows)
- `build/` (temporal)
- `dist/` (temporal)

**2. En Windows, instalar Python 3.8+:**

Descargar de: https://www.python.org/downloads/

Durante instalación: ✅ Marcar "Add Python to PATH"

**3. En Windows, abrir PowerShell en la carpeta del proyecto:**

```powershell
# Crear entorno virtual
python -m venv venv

# Activar entorno
venv\Scripts\activate

# Instalar dependencias
pip install -r requirements.txt

# Verificar que todo está OK
python verify_setup.py
```

**4. Buildear:**

```powershell
python build_scripts\build_windows.py --clean
```

**5. Resultado:**

```
dist\BuenaLive.exe  ← ¡Aquí está!
```

---

## ⚡ Comparación

| | GitHub Actions | Windows Manual |
|---|---|---|
| **Requiere Windows** | ❌ No | ✅ Sí |
| **Tiempo** | 10 min (automático) | 15 min (manual) |
| **Costo** | Gratis | Gratis |
| **Repetible** | ✅ Siempre igual | ⚠️ Puede variar |
| **Mac + Windows** | ✅ Ambos | ⚠️ Solo Windows |

---

## 🎯 Recomendación

**Usar GitHub Actions** (Opción 1):
- Es más rápido
- No necesitás Windows
- Builds automáticos cada vez que publiques
- Professional workflow

**Solo usar Windows manual si:**
- No querés/podés usar GitHub
- Necesitás el .exe AHORA mismo y tenés Windows disponible

---

## 📦 Estructura de archivos necesarios en Windows

Si vas por Opción 2, necesitás copiar:

```
buena-live/
├── main.py ✅
├── version.py ✅
├── updater.py ✅
├── credential_manager.py ✅
├── credentials.json ✅
├── buena-live.spec ✅
├── requirements.txt ✅
├── build_scripts/ ✅
│   ├── build_windows.py ✅
│   └── publish_update.py ✅
├── assets/ ✅
│   ├── buena-logo.png ✅
│   └── buena-logo.ico ✅
└── verify_setup.py ✅
```

**NO copiar:**
- `venv/` ❌
- `build/` ❌
- `dist/` ❌
- `.git/` ❌ (opcional)
- `__pycache__/` ❌

---

## 🆘 Troubleshooting

### GitHub Actions: "Workflow not found"

**Causa**: No subiste `.github/workflows/build-release.yml`

**Solución**:
```bash
git add .github/
git commit -m "Add GitHub Actions workflow"
git push origin main
```

### GitHub Actions: "Build fails"

Ver logs en: `https://github.com/TU_USUARIO/buena-live/actions`

Click en el workflow que falló → Ver error específico

### Windows: "Python not found"

**Solución**: Reinstalar Python y marcar "Add to PATH"

### Windows: "pip not found"

**Solución**:
```powershell
python -m pip install --upgrade pip
```

---

## 💡 Tips

### Builds automáticos para cada versión

Con GitHub Actions, cada vez que publiques una nueva versión:

```bash
# Cambiar versión
nano version.py  # 1.0.0 → 1.0.1

# Commit
git add version.py
git commit -m "Bump to 1.0.1"
git push

# Tag (dispara build automático)
git tag v1.0.1
git push origin v1.0.1

# Esperar 10 min → ¡Listo! Mac .dmg y Windows .exe en Releases
```

### Probar el .exe en Windows

Una vez que tengas el .exe:

1. **Copiarlo a una PC Windows**
2. **Ejecutar**: Doble click en `BuenaLive.exe`
3. **Verificar**:
   - ✅ Ventana abre con logo
   - ✅ Título dice "v1.0.0"
   - ✅ Botón "Buscar actualizaciones" existe
   - ✅ Funcionalidad básica trabaja

---

## ✅ Checklist

**Para GitHub Actions:**
- [ ] Código subido a GitHub
- [ ] Archivo `.github/workflows/build-release.yml` existe
- [ ] Tag creado: `git tag v1.0.0`
- [ ] Tag pusheado: `git push origin v1.0.0`
- [ ] Workflow corriendo (ver /actions)
- [ ] Release creado automáticamente
- [ ] .exe descargado desde Releases

**Para Windows manual:**
- [ ] Archivos copiados a Windows
- [ ] Python instalado
- [ ] Entorno virtual creado
- [ ] Dependencias instaladas
- [ ] `verify_setup.py` pasa OK
- [ ] Build ejecutado
- [ ] `dist/BuenaLive.exe` existe
- [ ] .exe probado

---

**¿Dudas?** Ver `BUILD_CON_GITHUB_ACTIONS.md` para más detalles sobre GitHub Actions.
